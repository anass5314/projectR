import { Box, Grid, Image, Text, Input, VStack } from "@chakra-ui/react";
import { useState } from "react";
import { data } from "../utils/data";

export const RecipeListPage = ({ onSelect }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredRecipes = data.hits.filter(
    ({ recipe }) =>
      recipe.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recipe.healthLabels.some((label) =>
        label.toLowerCase().includes(searchTerm.toLowerCase())
      )
  );

  return (
    <VStack
      spacing={6}
      align="stretch"
      p={5}
      backgroundColor="gray.50"
      minHeight="100vh"
    >
      <Input
        placeholder="Search for recipes or health labels..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        size="lg"
        borderRadius="md"
        boxShadow="sm"
        py={3}
      />
      <Grid
        templateColumns={{ base: "1fr", md: "1fr 1fr", lg: "1fr 1fr 1fr" }}
        gap={6}
      >
        {filteredRecipes.map(({ recipe }, index) => (
          <Box
            key={index}
            p={4}
            shadow="md"
            borderWidth={1}
            borderRadius="md"
            backgroundColor="white"
            onClick={() => onSelect(recipe)}
            _hover={{
              cursor: "pointer",
              bg: "gray.100",
              transform: "scale(1.02)",
              transition: "all 0.2s",
            }}
            transition="all 0.2s"
          >
            <Image
              borderRadius="md"
              width="50%"
              objectFit="cover"
              src={recipe.image}
              alt={recipe.label}
            />
            <Text
              mt={4}
              fontSize="xl"
              fontWeight="bold"
              color="teal.600"
              lineHeight="short"
            >
              {recipe.label}
            </Text>
            <Text mt={2} fontSize="sm" fontWeight="semibold">
              Diet: {recipe.dietLabels.join(", ")}
            </Text>
            <Text mt={1} fontSize="sm" color="gray.600">
              Health: {recipe.healthLabels.slice(0, 2).join(", ")}...
            </Text>
            <Text mt={1} fontSize="sm" color="gray.600">
              Meal: {recipe.mealType.join(", ")}
            </Text>
          </Box>
        ))}
      </Grid>
    </VStack>
  );
};
