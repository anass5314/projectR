import { Box, Grid, Image, Text, Input, VStack } from "@chakra-ui/react";
import { useState } from "react";
import { data } from "../utils/data";

export const RecipeListPage = ({ onRecipeClick }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredRecipes = data.hits.filter(
    ({ recipe }) =>
      recipe.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recipe.healthLabels.some((label) =>
        label.toLowerCase().includes(searchTerm.toLowerCase())
      )
  );

  return (
    <VStack spacing={4} align="stretch">
      <Input
        placeholder="Search"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <Grid
        templateColumns={{ base: "1fr", md: "1fr 1fr", lg: "1fr 1fr 1fr" }}
        gap={6}
      >
        {filteredRecipes.map(({ recipe }, index) => (
          <Box
            key={index}
            p={5}
            shadow="md"
            borderWidth={1}
            borderRadius="md"
            onClick={() => onRecipeClick(recipe)}
            _hover={{ cursor: "pointer", bg: "gray.100" }}
          >
            <Image
              borderRadius="md"
              boxSize="50%"
              objectFit="cover"
              src={recipe.image}
              alt={recipe.label}
            />
            <Text mt={4} fontSize="xl" fontWeight="semibold" lineHeight="short">
              {recipe.label}
            </Text>
            <Text mt={1}>{recipe.dietLabels.join(", ")}</Text>
            <Text mt={1}>{recipe.healthLabels.join(", ")}</Text>
            <Text mt={1}>Cautions: {recipe.cautions.join(", ") || "None"}</Text>
            <Text mt={1}>Meal Type: {recipe.mealType.join(", ")}</Text>
            <Text mt={1}>Dish Type: {recipe.dishType.join(", ")}</Text>
          </Box>
        ))}
      </Grid>
    </VStack>
  );
};
