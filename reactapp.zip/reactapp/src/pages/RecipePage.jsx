import {
  Box,
  Button,
  Image,
  Text,
  VStack,
  List,
  ListItem,
} from "@chakra-ui/react";

export const RecipePage = ({ recipe, onBack }) => {
  return (
    <VStack spacing={4} align="stretch">
      <Button onClick={onBack}>Back</Button>
      <Image
        borderRadius="md"
        boxSize="50%"
        objectFit="cover"
        src={recipe.image}
        alt={recipe.label}
      />
      <Text fontSize="2xl" fontWeight="semibold">
        {recipe.label}
      </Text>
      <Box>
        <Text>Diet Label: {recipe.dietLabels.join(", ")}</Text>
        <Text>Health Labels: {recipe.healthLabels.join(", ")}</Text>
        <Text>Cautions: {recipe.cautions.join(", ") || "None"}</Text>
        <Text>Meal Type: {recipe.mealType.join(", ")}</Text>
        <Text>Dish Type: {recipe.dishType.join(", ")}</Text>
        <Text>Total Cooking Time: {recipe.totalTime} minutes</Text>

        <Text mt={2} fontWeight="semibold">
          Ingredients:
        </Text>
        <Box
          maxH="200px"
          overflowY="scroll"
          borderWidth="1px"
          borderRadius="md"
          p={2}
        >
          <List spacing={1}>
            {recipe.ingredientLines.map((ingredient, index) => (
              <ListItem key={index}>{ingredient}</ListItem>
            ))}
          </List>
        </Box>

        <Text mt={2}>Servings: {recipe.yield}</Text>

        <Text mt={2} fontWeight="semibold">
          Nutrients:
        </Text>
        <Box
          maxH="200px"
          overflowY="scroll"
          borderWidth="1px"
          borderRadius="md"
          p={2}
        >
          <List spacing={1}>
            {Object.entries(recipe.totalNutrients).map(([key, nutrient]) => (
              <ListItem key={key}>
                {nutrient.label}: {nutrient.quantity.toFixed(2)} {nutrient.unit}
              </ListItem>
            ))}
          </List>
        </Box>
      </Box>
    </VStack>
  );
};
